<?php 

class User_model {
    private $nama = 'Meli Afriani';

    public function getUser()
    {
        return $this->nama;
    }
}